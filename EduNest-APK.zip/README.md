# EduNest APK

1. ارفع محتويات المجلد ده كله (بما فيهم `.github`) على Repository جديد في GitHub.
2. افتح تبويب **Actions** ← **Build APK** ← **Run workflow** (أو أي Push على main بيبنيه تلقائي).
3. بعد ما يخلص (3-5 دقايق) افتح العملية ونزّل **EduNest-debug-apk** من Artifacts، فكّ الـ zip وثبّت الـ APK.

## تعديلات
- كود التطبيق في `app/src/main/assets/index.html`. عدّله وارفعه وهيتبني APK جديد.
- الأيقونة: استبدل `app/src/main/assets/icon-192.png` و`icon-512.png` بأيقونتك (الأيقونات الحالية مؤقتة).
- أول مرة تفتح التطبيق هيطلب رابط Supabase والمفتاح (أو حطهم في `index.html` مكان `PASTE_...`).
